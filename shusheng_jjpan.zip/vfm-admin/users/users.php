<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$7s1TQyHw$SNu7ezjErMbUL3Zlz1U9i0',
    'role' => 'superadmin',
  ),
);
